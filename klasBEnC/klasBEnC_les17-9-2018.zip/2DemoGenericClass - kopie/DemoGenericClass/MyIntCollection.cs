﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoGenericClass
{
   class MyIntCollection
   {
      private int[] array = new int[10];
      private int cursor = 0;

      public void Add(int n)
      {
         if (cursor < 10)
            array[cursor++] = n;
      }

      public override string ToString()
      {
         string str = "";
         foreach (int i in array)
            str += i + ", ";

         return str;
      }
   }
}
