﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoGenericClass
{
    class Program
    {
        static void Main(string[] args)
        {
            MyIntCollection myIntCollection = new MyIntCollection();
            myIntCollection.Add(12);
            myIntCollection.Add(33);
            Console.WriteLine(myIntCollection);

            #region Generic versie
            //...
            #endregion


            Console.ReadKey();
        }
    }
}
