﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExerciseGenericSwap
{
   class Program
   {
      static void SwapInts(ref int a, ref int b)
      {
         int temp = a;
         a = b;
         b = temp;
      }

      #region Generic
      //...
      #endregion

      static void Main(string[] args)
      {
         int i1 = 88;
         int i2 = 77;
         SwapInts(ref i1, ref i2);
         Console.WriteLine("i1: " + i1 + " i2: " + i2);


         #region Generic
         //... 
         #endregion

         Console.ReadKey();
      }
   }
}
