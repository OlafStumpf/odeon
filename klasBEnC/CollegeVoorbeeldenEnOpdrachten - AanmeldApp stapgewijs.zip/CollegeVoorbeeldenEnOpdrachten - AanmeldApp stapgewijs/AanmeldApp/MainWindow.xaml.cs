﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BMI;

namespace AanmeldApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MeldMeerdere_Click(object sender, RoutedEventArgs e)
        {
         #region g
         var dlg = new NaamWindowModeless();
         dlg.Owner = this;
         #region h
         dlg.NameFound += DlgOnNameFound; 
         #endregion

         // Open the dialog box modally
         dlg.Show(); 
         #endregion
      }

      #region f
      private void DlgOnNameFound(object sender, NaamEventArgs eventArgs)
      {
         string naam = eventArgs.Naam;
         Namenlijst.Items.Add(naam);
      } 
      #endregion

      private void MeldEen_Click(object sender, RoutedEventArgs e)
        {
            NaamWindow dlg = new NaamWindow();
            dlg.Owner = this;
            if (dlg.ShowDialog() == true) //open als modale dialoog
            {
                string naam = dlg.Naam;
                Namenlijst.Items.Add(naam);
            }
        }
    }
}
