﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BMI
{

   #region b
   public delegate void NameFoundEvent(object sender, NaamEventArgs e);
   //public delegate void EventHandler<NaamEventArgs>(object sender, TEventArgs e);

   #endregion

   /// <summary>
   /// Interaction logic for NaamWindow.xaml
   /// </summary>
   public partial class NaamWindowModeless : Window
    {
      #region c
      public event NameFoundEvent NameFound; 
      #endregion

      public NaamWindowModeless()
        {
            InitializeComponent();
        }

        private void VoegtoeKnop_Click(object sender, RoutedEventArgs e)
        {
         //NameFound(this, new NaamEventArgs(NaamBox2.Text));
         #region e
         OnNameFound();
         #endregion
         NaamBox2.Clear();
        }

        private void Window_ContentRendered(object sender, EventArgs e)
        {
            NaamBox2.Focus();
        }

      #region e
      protected virtual void OnNameFound()
      {
         if (NameFound != null)
         {
            NameFound(this, new NaamEventArgs(NaamBox2.Text));
         }
      }
      #endregion
   }

   #region d
   public class NaamEventArgs : EventArgs
   {
      public string Naam { get; set; }

      public NaamEventArgs(string naam) : base()
      {
         Naam = naam;
      }
   } 
   #endregion
}
