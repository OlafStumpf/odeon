﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo3DelegateObserverSimpleModel
{
    class Program
    {
        static void Main(string[] args)
        {
            Model model = new Model();

            ViewGetal vg = new ViewGetal(model);
            ViewStreepjes vt = new ViewStreepjes(model);

            model.IncreaseModel(5);
            model.DecreaseModel(3);

            Console.ReadKey();
        }
    }
}
