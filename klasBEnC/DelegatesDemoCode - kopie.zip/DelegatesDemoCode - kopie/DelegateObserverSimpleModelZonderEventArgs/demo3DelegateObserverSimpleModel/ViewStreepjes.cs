﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo3DelegateObserverSimpleModel
{
    public class ViewStreepjes
    {
        public ViewStreepjes(Model m)
        {
            //m.AddObserver(ShowData);
            m.Obs += ShowData;
        }

        public void ShowData(Model model)
        {
            Console.Write("Streepjes: ");
            // Gebruik maken van referentie aan model dat al in constructor is gelegd:
            //for (int i = 0; i<m.Getal; i++)
            //    Console.Write("|");
            // Alternatief gebruik maken van eerste parameter:
            for (int i = 0; i < model.Getal; i++)
                Console.Write("|");

            Console.WriteLine();
        }
    }
}
