﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo3DelegateObserverSimpleModel
{
    public class ViewGetal
    {
        public ViewGetal(Model m)
        {
            //m.AddObserver(ShowData);  // Zou een alternatieve oplossing kunnen i.p.v. gebruik van Event
            m.Obs += ShowData;
            //m.Obs = null;
            //m.Obs = ShowData; // Lees foutmelding, als Obs in Model als Event is gedeclareerd.
        }

        public void ShowData(Model model)
        {
            //Console.WriteLine("Getal just printed: " + m.Getal);
            //Alternatief gebruik maken van eerste parameter:
            Console.WriteLine("Getal just printed: " + model.Getal);
        }
    }
}
