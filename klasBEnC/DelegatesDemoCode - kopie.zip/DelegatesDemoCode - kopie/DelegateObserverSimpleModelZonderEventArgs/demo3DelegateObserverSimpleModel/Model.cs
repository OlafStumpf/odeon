﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace demo3DelegateObserverSimpleModel
{
    public delegate void Observer(Model model);

    public class Model
    {
        // Erg simpel model ....
        public int Getal { get; set; }

        //public Observer Obs;
        public event Observer Obs;

        //private Observer Obs;
        //public void AddObserver(Observer o)
        //{
        //    Obs += o;
        //}

        public void IncreaseModel(int i)
        {
            Getal = Getal + i;

            //observers worden aangeroepen
            Obs(this);
        }

        public void DecreaseModel(int i)
        {
            Getal = Getal - i;

            //observers worden aangeroepen
            Obs(this);
        }
    }
}
