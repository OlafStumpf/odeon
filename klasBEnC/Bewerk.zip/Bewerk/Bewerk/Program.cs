﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bewerk
{
   delegate T Bewerking<T>(T t);
   class Program
   {
    
      static void Main(string[] args)
      {
         Bewerking<int> bewerking = Verdubbel;
         int resultaat = bewerking(5);
         Console.WriteLine(resultaat);

         bewerking = Kwadraat;
         resultaat = bewerking(5);
         Console.WriteLine(resultaat);

         int[] waarden = { 3, 9, 10 };
         Bewerk(waarden, Kwadraat);
         foreach (int i in waarden) { Console.Write(i + " "); }   // 9  81  100

         Bewerk(waarden, Verdubbel);
         foreach (int i in waarden) { Console.Write(i + " "); }   // 18  162  200

         double[] doubleWaarden = { 3.1, 9.4, 10.5 };
         Bewerk(doubleWaarden, Kwadraat);
         foreach (double d in doubleWaarden)
            Console.Write(d + " ");

         string[] woorden = { "kies", "vet", "durf" };
         Bewerk(woorden, Hoofdletters);
         foreach (string s in woorden)
            Console.Write(s + " ");

         Console.ReadKey();
      }

      static int Verdubbel(int i)
      {
         return i * 2;
      }

      //static T Kwadraat<T> (T t)
      //{
      //   return t*t;
      //}



      static int Kwadraat(int i)
      {
         return i * i;
      }
      static double Kwadraat(double d)
      {
         return d * d;
      }

      static string Hoofdletters(string s)
      {
         return s.ToUpper();
      }

      //static void Bewerk(int[] waarden, Bewerking<int> b )
      //{
      //   for (int i = 0; i < waarden.Length; i++)
      //      waarden[i] = b(waarden[i]);
      //}

      static void Bewerk<T>(T[] waarden, Bewerking<T> b)
      {
         for (int i = 0; i < waarden.Length; i++)
            waarden[i] = b(waarden[i]);
      }
   }
}
