﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4bExercise
{
    class Horse : Animal
    {
        public override void Move()
        {
            Console.WriteLine("Horse move");
        }

        public override void Speak()
        {
            //base.Speak();
            Console.WriteLine("hiiii");
        }
    }
}
