﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4bExercise
{
    abstract class Animal
    {
        public string Name { get; set; }

        //public virtual void Move()
        //{
        //    Console.WriteLine("Animal move");
        //}

        public abstract void Move();

        public virtual void Speak()
        {
            Console.WriteLine("silence .....");
        }
    }
}
