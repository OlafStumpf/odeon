﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4bExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Animal> list = new List<Animal>();
            //list.Add(new Animal());
            list.Add(new Fish());
            list.Add(new Horse());

            foreach (Animal a in list) { 
                a.Move();
                a.Speak();
            }

            Console.ReadKey();
        }
    }
}
