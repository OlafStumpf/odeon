﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExerciseGenericSwap
{
   class Program
   {
      static void SwapInts(ref int a, ref int b)
      {
         int temp = a;
         a = b;
         b = temp;
      }

      #region Generic
      static void Swap<T>(ref T t1, ref T t2)
      {
         T temp = t1;
         t1 = t2;
         t2 = temp;
      } 
      #endregion

      static void Main(string[] args)
      {
         int i1 = 88;
         int i2 = 77;
         SwapInts(ref i1, ref i2);
         Console.WriteLine("i1: " + i1 + " i2: " + i2);


         #region Generic
         int x = 3;
         int y = 9;
         Swap<int>(ref x, ref y);
         Console.WriteLine("x: " + x + " y: " + y);
         char a = 'h'; char b = 'I';
         Swap(ref a, ref b);
         Console.WriteLine("a: " + a + " b: " + b); 
         #endregion

         Console.ReadKey();
      }
   }
}
