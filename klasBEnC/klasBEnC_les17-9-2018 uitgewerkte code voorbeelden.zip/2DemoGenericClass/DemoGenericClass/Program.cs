﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoGenericClass
{
    class Program
    {
        static void Main(string[] args)
        {
            MyIntCollection myIntCollection = new MyIntCollection();
            myIntCollection.Add(12);
            myIntCollection.Add(33);
            Console.WriteLine(myIntCollection);

            #region Generic versie
            MyCollection<char> myCollection = new MyCollection<char>();
            myCollection.Add('h');
            myCollection.Add('i');

            Console.WriteLine(myCollection);

            MyCollection<int> myCollection2 = new MyCollection<int>();
            myCollection2.Add(12);
            myCollection2.Add(9);

            Console.WriteLine(myCollection2); 
            #endregion


            Console.ReadKey();
        }
    }
}
