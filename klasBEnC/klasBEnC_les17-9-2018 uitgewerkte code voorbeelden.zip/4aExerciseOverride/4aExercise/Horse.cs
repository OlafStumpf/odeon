﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4aExercise
{
    class Horse: Animal
    {

        public override void Move()
        {
            Console.WriteLine("Horse move (override)");
        }

        //public void Move()
        //{
        //    Console.WriteLine("Horse move (no override nor new)");
        //}

        //public new void Move()  // Met new zelfde als 'public void Move()', maar je geeft aan dat het bewust is en onderdrukt daarmee de warning.
        //{
        //    Console.WriteLine("Horse move (new)");
        //}
    }
}
