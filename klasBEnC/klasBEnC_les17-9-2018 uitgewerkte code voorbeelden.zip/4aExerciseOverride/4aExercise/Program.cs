﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4aExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal animal_1 = new Animal();
            animal_1.Move();

            Horse horse = new Horse();
            horse.Move();

            Animal animal_2 = new Horse();
            animal_2.Move();

            Console.ReadKey();

        }
    }
}
