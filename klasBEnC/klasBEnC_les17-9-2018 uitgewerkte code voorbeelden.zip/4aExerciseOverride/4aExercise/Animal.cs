﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4aExercise
{
    class Animal
    {

        public virtual void Move()
        {
            Console.WriteLine("Animal move");
        }
    }
}
