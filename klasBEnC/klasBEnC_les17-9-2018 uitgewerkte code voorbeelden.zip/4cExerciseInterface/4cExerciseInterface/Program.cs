﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4cExerciseInterface
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IAnimal> list = new List<IAnimal>();
            //list.Add(new Animal());
            list.Add(new Fish());
            list.Add(new Horse());

            foreach (IAnimal a in list)
                a.Move();

            Console.ReadLine();
        }
    }
}
