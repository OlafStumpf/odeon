﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExerciseGenericMijnGenericArray
{
    public class MijnIntArray
    {
        private int[] array;
        public MijnIntArray(int size)
        {
            array = new int[size];
        }
        public int GeefItem(int index)
        {
            return array[index];
        }
        public void ZetItem(int index, int value)
        {
            array[index] = value;
        }
    }
}
