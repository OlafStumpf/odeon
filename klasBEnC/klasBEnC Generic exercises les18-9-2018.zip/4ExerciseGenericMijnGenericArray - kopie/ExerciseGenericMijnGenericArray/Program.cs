﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExerciseGenericMijnGenericArray
{
   class Program
   {
      static void Main(string[] args)
      {
         MijnIntArray intArray = new MijnIntArray(4);
         for (int i = 0; i < 4; i++)
         {
            intArray.ZetItem(i, i * i);
         }
         for (int i = 0; i < 4; i++)
         {
            Console.Write(intArray.GeefItem(i) + " ");
         }
         Console.WriteLine();

         MijnGenericArray<int> intArray2 = new MijnGenericArray<int>(4);
         for (int i = 0; i < 4; i++)
         {
            intArray2.ZetItem(i, i * 2);
         }
         for (int i = 0; i < 4; i++)
         {
            Console.Write(intArray2.GeefItem(i) + " ");
         }
         Console.WriteLine();

         MijnGenericArray<char> charArray = new MijnGenericArray<char>(7);
         for (int i = 0; i < 7; i++)
         {
            charArray.ZetItem(i, (char)(i + 97));
         }
         for (int i = 0; i < 7; i++)
         {
            Console.Write(charArray.GeefItem(i) + " ");
         }

         Console.ReadKey();
      }
   }
}
