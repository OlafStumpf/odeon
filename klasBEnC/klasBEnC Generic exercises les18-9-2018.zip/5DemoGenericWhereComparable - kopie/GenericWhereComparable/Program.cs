﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericWhereComparable
{
    class Program
    {
        public static int Maximum(int first, int second, int third)
        {
            int max = first;
            if (second.CompareTo(max) > 0)
                max = second;
            if (third.CompareTo(max) > 0)
                max = third;

            return max;
        }
        


        static void Main(string[] args)
        {
            Console.WriteLine(Maximum(9, 7, 2));


            Persoon persoon1 = new Persoon("Moniek", 170);
            Persoon persoon2 = new Persoon("Peter", 180);
            Persoon persoon3 = new Persoon("Sandra", 169);
            //Console.WriteLine(Maximum<Persoon>(persoon1, persoon2, persoon3));        // <Persoon> niet nodig, is voor compiler al duidelijk gezien de aanroep met 3 personen
            Console.WriteLine(Maximum(persoon1, persoon2, persoon3));

            Console.ReadKey();
        }
    }
}
