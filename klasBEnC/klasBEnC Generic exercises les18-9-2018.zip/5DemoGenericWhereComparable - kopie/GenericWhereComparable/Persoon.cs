﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericWhereComparable
{
    public class Persoon : IComparable<Persoon>
    {
        public string Naam { get; set; }
        public int Lengte { get; set; }

        public Persoon(string nm, int lngt)
        {
            Naam = nm;
            Lengte = lngt;
        }

        public int CompareTo(Persoon other)
        {
            if (Lengte < other.Lengte)
                return -1;
            else if (Lengte > other.Lengte)
                return 1;
            else
                return 0;
            //return Lengte.CompareTo(other.Lengte);
        }

        public override string ToString()
        {
            return "Naam: " + Naam + "   Lengte: " + Lengte;
        }
    }
}
